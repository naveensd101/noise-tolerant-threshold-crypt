For installing, please type 'make install'.

Notice that 'python setup.py install' is not enough for building all
the required files, as 'swig' is not (yet?) properly supported by
python distutils.
